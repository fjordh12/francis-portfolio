const foodList = [
    { "name": "Pizza" },
    { "name": "Burger" },
    { "name": "Sushi" },
    { "name": "Pasta" },
    { "name": "Salad" },
    { "name": "Steak" },
    { "name": "Noodles" }
    // Add more food items as needed
];

const resultBox = document.querySelector('.results');
const inputBox = document.querySelector('.search-bar-input');

// Function to display search results
const displayResults = function (result) {
    const limitedResults = result.slice(0, 5);
    const resultHTML = limitedResults.map(function (food) {
        return `<li onclick=selectInput(this)>
            ${food.name}
        </li>`;
    });
    resultBox.innerHTML = "<ul>" + resultHTML.join('') + "</ul>";
};

// Event listener for input changes
inputBox.onkeyup = function (e) {
    let result = [];
    const input = inputBox.value.toLowerCase();
    if (input.length === 0) {
        resultBox.innerHTML = "";
    }
    if (input.length) {
        result = foodList.filter((food) => {
            return food.name.toLowerCase().includes(input);
        });
        displayResults(result);
    }
};

// Function to handle input selection
function selectInput(food) {
    inputBox.value = food.innerText;
    resultBox.innerHTML = "";
}

// Function to handle search button click
document.querySelector('.findFood_btn').onclick = function(event) {
    event.preventDefault(); // Prevent default anchor behavior
    const searchTerm = inputBox.value.toLowerCase();
    if(searchTerm.includes("sushi")) window.location.href = 'sushi.html'; // Redirect to sushi.html
    else if(searchTerm.includes("pizza")) window.location.href = 'pizza.html'; // Redirect to pizza.html
    else if (searchTerm.includes("burger")) window.location.href = 'burger.html'; // Redirect to burger.html
    else if (searchTerm.includes("steak")) window.location.href = 'steak.html'; // Redirect to steak.html
    else if (searchTerm.includes("noodles") || searchTerm.includes("noodle")) window.location.href = 'noodles.html'; // Redirect to noodles.html
    else alert("No results found for " + inputBox.value);
};

// Redirect order button to the payment page
function paymentPage() {
    window.location.href = 'payment.html';
}
