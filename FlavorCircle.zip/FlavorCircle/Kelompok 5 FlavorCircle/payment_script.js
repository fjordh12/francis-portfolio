function redirect()
{
    window.location = 'Flavorcircle.html'
}

function updateQuantity(change, quantityElement, priceElement) 
{
    let quantity = parseInt(quantityElement.innerText);
    let price = 25000;
    let totalElement = document.getElementById("total-price");

    // Update quantity
    quantity += change;
    if (quantity < 1) quantity = 1; // Prevent quantity from going below 1

    // Update displayed quantity and subtotal
    quantityElement.innerText = quantity;
    priceElement.innerText = "Rp. " + (quantity * price).toLocaleString();

    //Total price
    let allPrices = document.querySelectorAll("#price");    //the price
    let totalPrice = 0; //temp var

    allPrices.forEach(priceItem => {
        totalPrice += parseInt(priceItem.innerText.replace(/\D/g, '')); 
        //Remove non-numeric chars and sum up prices
    });

    //update the total price
    totalElement.innerText = "Total Price: Rp. " + totalPrice.toLocaleString();
}