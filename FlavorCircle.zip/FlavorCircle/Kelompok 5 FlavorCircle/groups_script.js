function FcPage()
{
    window.location.href = 'Flavorcircle.html';
}

function buttonClicked(button) 
{
    if(button.innerText === "Join") 
    {
        button.innerText = "Joined";
        button.style.backgroundColor = "#28a745";
    } 

    else if(button.innerText === "Joined") 
    {
        button.innerText = "Join";
        button.style.backgroundColor = "#007BFF";
    } 
    
    else if(button.innerText === "Follow") 
    {
        button.innerText = "Following";
        button.style.backgroundColor = "#28a745";
    }

    else if(button.innerText === "Following") 
    {
        button.innerText = "Follow";
        button.style.backgroundColor = "#007BFF";
    }
}